import pyodbc
import bcrypt

# Database configuration
DB_SERVER = 'DESKTOP-BSC7DMC\SQLEXPRESS'
DB_DATABASE = 'tse_data'
DB_USER = 'sa'
DB_PASSWORD = 'tiger'

# Connection string
connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={DB_SERVER};DATABASE={DB_DATABASE};UID={DB_USER};PWD={DB_PASSWORD}'

# SQL commands to create tables
create_operatorr_table_query = '''
CREATE TABLE Operatorr (
   id INT PRIMARY KEY IDENTITY(1,1),
   username VARCHAR(100) NOT NULL,
   password VARCHAR(100) NOT NULL
);

ALTER TABLE Operatorr ADD CONSTRAINT unique_operatorr_username UNIQUE (username);
'''

create_managerr_table_query = '''
CREATE TABLE Managerr (
   id INT PRIMARY KEY IDENTITY(1,1),
   username VARCHAR(100) NOT NULL,
   password VARCHAR(100) NOT NULL
);

ALTER TABLE Managerr ADD CONSTRAINT unique_managerr_username UNIQUE (username);
'''

create_tsee_table_query = '''
CREATE TABLE Tsee (
   id INT PRIMARY KEY IDENTITY(1,1),
   username VARCHAR(100) NOT NULL,
   password VARCHAR(100) NOT NULL
);

ALTER TABLE Tsee ADD CONSTRAINT unique_tsee_username UNIQUE (username);
'''

# Function to execute SQL queries
def execute_query(query, values=None):
    try:
        conn = pyodbc.connect(connection_string)
        cursor = conn.cursor()
        if values:
            cursor.execute(query, values)
        else:
            cursor.execute(query)
        conn.commit()
        print("Query executed successfully.")
    except Exception as e:
        print(f"Error executing query: {str(e)}")
    finally:
        cursor.close()
        conn.close()

# Create tables
execute_query(create_operatorr_table_query)
execute_query(create_managerr_table_query)
execute_query(create_tsee_table_query)

# Insert data with hashed passwords
def insert_user(table, username, plain_password):
    hashed_password = bcrypt.hashpw(plain_password.encode('utf-8'), bcrypt.gensalt())
    insert_query = f"INSERT INTO {table} (username, password) VALUES (?, ?)"
    execute_query(insert_query, (username, hashed_password.decode('utf-8')))

# Insert sample users
insert_user('Operatorr', 'operatorr', 'operatorr@123')
insert_user('Managerr', 'managerr', 'managerr@123')
insert_user('Tsee', 'tsee', 'tsee@123')